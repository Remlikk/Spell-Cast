advancement revoke @s[scores={scast.cooldown=0}] only scast:using_spell

execute if score @s scast.cooldown = @s scast.cooldown_initial run advancement revoke @s[predicate=scast:no_oneshot_cooldown, tag=scast.oneshot] only scast:using_spell

execute unless score @s scast.cooldown matches 0 run advancement revoke @s only scast:using_cooldown

execute if score @s[tag=scast.oneshot] scast.cooldown matches ..0 run return run tag @s remove scast.oneshot

scoreboard players remove @s[scores={scast.cooldown=1..}] scast.cooldown 1
scoreboard players add @s[scores={scast.cooldown=..-1}] scast.cooldown 1
tag @s[scores={scast.cooldown=..-1}, tag=!scast.oneshot_cooldown] add scast.oneshot_cooldown

tag @s[tag=scast.oneshot_cooldown, scores={scast.cooldown=0}] remove scast.oneshot_cooldown