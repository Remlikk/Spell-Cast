data modify storage scast:data previous_spell set from storage scast:data current_spell_path
data remove storage scast:data current_spell_path

$execute store result score #scast scast.success run data modify storage scast:data current_spell_path set from storage scast:data $(caster_id).sequence
execute if score #scast scast.success matches 1 store success score #scast scast.success run function scast:casting/resolve_from_id with storage scast:data