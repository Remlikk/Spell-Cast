tag @s[predicate=scast:no_oneshot_cooldown, tag=scast.notnull] add scast.oneshot
advancement revoke @s only scast:oneshot_casting