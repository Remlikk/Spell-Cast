data remove storage scast:catalog selected_spell
$execute store success score #scast scast.success run data modify storage scast:catalog selected_spell set from storage scast:catalog spells[]."$(current_spell_path)"

execute unless score #scast scast.success matches 1 run return fail