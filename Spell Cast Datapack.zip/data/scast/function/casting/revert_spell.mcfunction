$data modify storage scast:data $(caster_id).sequence set from storage scast:data previous_spell
data modify storage scast:data current_spell_path set from storage scast:data previous_spell