$scoreboard players set @s scast.cooldown $(cooldown)
$scoreboard players set @s scast.cooldown_initial $(cooldown)