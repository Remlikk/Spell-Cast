execute unless score @s scast.cooldown matches 0 unless score @s scast.cooldown = @s scast.cooldown_initial run return fail

data remove storage scast:catalog selected_spell
execute store result storage scast:data caster_id int 1 run scoreboard players get @s scast.caster_id
function scast:casting/get_spell with storage scast:data

function scast:casting/set_cooldown with storage scast:catalog selected_spell
advancement revoke @s only scast:using_cooldown

execute if score #scast scast.success matches 1 run function scast:casting/cast_spell with storage scast:catalog selected_spell