scoreboard players remove @s scast.casting 1
advancement revoke @s[scores={scast.casting=1..}] only scast:casting_release
execute if score @s scast.casting matches 0 run function scast:casting_release