execute unless score @s scast.caster_id matches 0.. run function scast:internal/setup_new_caster

scoreboard players set @s scast.rotX 0
scoreboard players set @s scast.rotY 0
scoreboard players set @s scast.posX 0
scoreboard players set @s scast.posY 0
scoreboard players set @s scast.posZ 0
scoreboard players set @s scast.posX_M 0
scoreboard players set @s scast.posY_M 0
scoreboard players set @s scast.posZ_M 0
execute store result score @s scast.rotX run data get entity @s Rotation[0] 10
execute store result score @s scast.rotY run data get entity @s Rotation[1] 10
execute store result score @s scast.posX_M run data get entity @s Pos[0] 100
execute store result score @s scast.posY_M run data get entity @s Pos[1] 100
execute store result score @s scast.posZ_M run data get entity @s Pos[2] 100

tag @s add scast.casting_init
execute anchored eyes run function scast:ui/spawn_nodes
tag @s remove scast.casting_init

tag @s add scast.casting

execute store result storage scast:data current_caster int 1 run scoreboard players get @s scast.caster_id
function scast:internal/clear_casting_cache with storage scast:data