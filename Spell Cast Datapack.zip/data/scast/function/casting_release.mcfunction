advancement revoke @a[scores={scast.casting=0}] only scast:casting_spell_init
function scast:ui/remove_nodes_init

execute store result storage scast:data caster_id int 1 run scoreboard players get @s scast.caster_id
execute store success score #scast scast.success run function scast:casting/get_spell with storage scast:data
execute if score #scast scast.success matches 1 run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 0.2 .56
execute if score #scast scast.success matches 1 run tag @s add scast.notnull
execute if score #scast scast.success matches 1 run advancement revoke @s only scast:using_cooldown
execute if score #scast scast.success matches 1 run function scast:ui/display_spell_name with storage scast:catalog selected_spell
execute if score #scast scast.success matches 0 run playsound minecraft:block.glass.break player @s ~ ~ ~ 1 1.3 1
execute if score #scast scast.success matches 0 run function scast:casting/revert_spell with storage scast:data

scoreboard players reset @a[scores={scast.casting=0}] scast.casting
tag @s remove scast.casting