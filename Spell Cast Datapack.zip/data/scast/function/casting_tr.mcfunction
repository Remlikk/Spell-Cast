scoreboard players set @s scast.casting 2
advancement revoke @s only scast:casting_spell
advancement revoke @s only scast:casting_release

execute anchored eyes run function scast:internal/raycast_select

execute store result score @s scast.posX run data get entity @s Pos[0] 100
execute store result score @s scast.posY run data get entity @s Pos[1] 100
execute store result score @s scast.posZ run data get entity @s Pos[2] 100

execute unless score @s scast.posX = @s scast.posX_M run return run function scast:ui/player_moved
execute unless score @s scast.posY = @s scast.posY_M run return run function scast:ui/player_moved
execute unless score @s scast.posZ = @s scast.posZ_M run return run function scast:ui/player_moved