scoreboard objectives add scast.casting dummy
scoreboard objectives add scast.cooldown dummy
scoreboard objectives add scast.cooldown_initial dummy
scoreboard objectives add scast.caster_id dummy
scoreboard objectives add scast.success dummy

scoreboard objectives add scast.posX dummy
scoreboard objectives add scast.posY dummy
scoreboard objectives add scast.posZ dummy
scoreboard objectives add scast.posX_M dummy
scoreboard objectives add scast.posY_M dummy
scoreboard objectives add scast.posZ_M dummy
scoreboard objectives add scast.rotX dummy
scoreboard objectives add scast.rotY dummy

scoreboard objectives add scast.iterate dummy

execute unless score #scast scast.caster_id matches 0.. run scoreboard players set #scast scast.caster_id 0
scoreboard players set #scast scast.success 0