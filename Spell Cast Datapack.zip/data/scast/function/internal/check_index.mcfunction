data remove storage scast:data iter_spell
$return run data modify storage scast:data iter_spell set from storage scast:catalog spells.[$(index)]