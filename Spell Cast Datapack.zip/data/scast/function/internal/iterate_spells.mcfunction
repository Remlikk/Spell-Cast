execute store result storage scast:data index int 1 run scoreboard players get #scast scast.iterate

execute store result score #scast scast.success run function scast:internal/check_index with storage scast:data
# Out of bounds (not found)
execute if score #scast scast.success matches 0 run return 0

execute if score #scast scast.success matches 1 run function scast:internal/get_sequence_at_index with storage scast:data
execute if score #scast scast.success matches 1 run function scast:internal/get_name_at_index with storage scast:data
$execute store success score #scast scast.success run execute if data storage scast:catalog {iter_spell:{name:"$(name)"}}
execute if score #scast scast.success matches 1 run return 1

scoreboard players add #scast scast.iterate 1

$execute if score #scast scast.success matches 0 run function scast:internal/iterate_spells {name:"$(name)"}