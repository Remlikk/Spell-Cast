execute store result storage scast:data index int 1 run scoreboard players get #scast scast.iterate
execute store result score #scast scast.success run function scast:internal/check_index with storage scast:data
execute if score #scast scast.success matches 1 run function scast:internal/print_name_at_index with storage scast:data
execute if score #scast scast.success matches 1 run scoreboard players add #scast scast.iterate 1
execute if score #scast scast.success matches 1 run function scast:internal/loop_spell_names