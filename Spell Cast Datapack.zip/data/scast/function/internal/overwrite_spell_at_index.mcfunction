$data modify storage scast:catalog spells[$(index)]."$(iter_sequence)".name set value $(new_spell_name)
$data modify storage scast:catalog spell_names[$(index)] set value $(new_spell_name)