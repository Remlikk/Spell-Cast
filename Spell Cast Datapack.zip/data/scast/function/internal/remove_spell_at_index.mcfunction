$data remove storage scast:catalog spells[$(index)]
$data remove storage scast:catalog spell_keys[$(index)]
$data remove storage scast:catalog spell_names[$(index)]