scoreboard players set @s scast.caster_id -1
scoreboard players set @s scast.cooldown 0
execute store result score @s scast.caster_id run scoreboard players add #scast scast.caster_id 1