execute unless block ~ ~ ~ air run summon minecraft:lightning_bolt
execute if block ~ ~ ~ air positioned ^ ^ ^1 if entity @s[distance=..32] run function scast:spells/lightning