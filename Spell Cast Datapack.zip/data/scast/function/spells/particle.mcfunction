particle flame ^ ^ ^2.1

execute positioned ^ ^ ^2.1 run damage @n[distance=..1] 4