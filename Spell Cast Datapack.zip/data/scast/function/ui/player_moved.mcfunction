execute store result score @s scast.posX_M run data get entity @s Pos[0] 100
execute store result score @s scast.posY_M run data get entity @s Pos[1] 100
execute store result score @s scast.posZ_M run data get entity @s Pos[2] 100

data merge storage scast:data {rotation: {x:0, y:0}}
execute store result storage scast:data rotation.x int 0.1 run scoreboard players get @s scast.rotX
execute store result storage scast:data rotation.y int 0.1 run scoreboard players get @s scast.rotY

tag @s add scast.reposition
execute anchored eyes run function scast:ui/summon_repositioned_root with storage scast:data rotation
execute as @n[type=marker, tag=scast.reposition] at @s run function scast:ui/reposition_ui
tag @s remove scast.reposition