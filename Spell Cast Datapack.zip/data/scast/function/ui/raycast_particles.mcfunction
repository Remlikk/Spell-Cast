particle minecraft:dust{color:[85,242,32],scale:0.2f} ~ ~0.1 ~
execute if entity @e[type=text_display, tag=scast.node, tag=scast.selected, distance=..0.02] run return fail
execute facing entity @n[type=text_display, tag=scast.node, tag=scast.selected] feet positioned ^ ^ ^.02 run function scast:ui/raycast_particles