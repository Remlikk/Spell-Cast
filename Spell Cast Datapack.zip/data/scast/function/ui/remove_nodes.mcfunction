$execute if score @s scast.caster_id matches $(caster_id) run kill @s

