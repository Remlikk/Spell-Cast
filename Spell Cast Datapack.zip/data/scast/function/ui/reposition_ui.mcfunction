rotate @s facing entity @n[type=player, tag=scast.reposition] eyes

execute rotated as @s as @e[type=text_display, tag=scast.node1] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^-0.75 ^0.75 ^
execute rotated as @s as @e[type=text_display, tag=scast.node2] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^-0.25 ^0.75 ^
execute rotated as @s as @e[type=text_display, tag=scast.node3] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^0.25 ^0.75 ^ 
execute rotated as @s as @e[type=text_display, tag=scast.node4] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^0.75 ^0.75 ^ 
                                                                                                                                                                                
execute rotated as @s as @e[type=text_display, tag=scast.node5] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^-0.75 ^0.25 ^
execute rotated as @s as @e[type=text_display, tag=scast.node6] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^-0.25 ^0.25 ^
execute rotated as @s as @e[type=text_display, tag=scast.node7] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^0.25 ^0.25 ^ 
execute rotated as @s as @e[type=text_display, tag=scast.node8] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^0.75 ^0.25 ^ 
                                                                                                                                                                                
execute rotated as @s as @e[type=text_display, tag=scast.node9] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^-0.75 ^-0.25 ^
execute rotated as @s as @e[type=text_display, tag=scast.node10] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^-0.25 ^-0.25 ^
execute rotated as @s as @e[type=text_display, tag=scast.node11] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^0.25 ^-0.25 ^
execute rotated as @s as @e[type=text_display, tag=scast.node12] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^0.75 ^-0.25 ^
                                                                                                                                                                                
execute rotated as @s as @e[type=text_display, tag=scast.node13] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^-0.75 ^-0.75 ^
execute rotated as @s as @e[type=text_display, tag=scast.node14] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^-0.25 ^-0.75 ^
execute rotated as @s as @e[type=text_display, tag=scast.node15] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^0.25 ^-0.75 ^
execute rotated as @s as @e[type=text_display, tag=scast.node16] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ^0.75 ^-0.75 ^

execute rotated as @s as @e[type=text_display, tag=scast.text] if score @s scast.caster_id = @n[type=marker, tag=scast.reposition] scast.caster_id run tp @s ~ ~ ~

kill