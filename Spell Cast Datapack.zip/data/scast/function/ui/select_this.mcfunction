execute if entity @s[tag=scast.selected_node] run return fail

data merge entity @s {text:{text:"⬤", color: "aqua"}}
data merge entity @s {transformation:{left_rotation:[0f,0f,0f,1f], right_rotation:[0f,0f,0f,1f], scale:[1.2f,1.2f,1.2f], translation:[0f,-0.025f,0f]}, interpolation_duration:2s}

tag @s add scast.selected

execute as @n[type=text_display, tag=scast.selected_node, distance=..3] if score @s scast.caster_id = @n[type=text_display, tag=scast.node, tag=scast.selected] scast.caster_id at @s run function scast:ui/raycast_particles

execute as @e[type=text_display, tag=scast.selected_node, distance=..3] if score @s scast.caster_id = @n[type=text_display, tag=scast.node, tag=scast.selected] scast.caster_id run function scast:ui/deselect_node

tag @s add scast.selected_node
tag @s remove scast.selected

execute store result storage scast:data caster_id int 1 run scoreboard players get @s scast.caster_id
function scast:internal/append_node_value with storage scast:data

execute as @a if score @s scast.caster_id = @s scast.caster_id at @s run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 0.2 .56