$execute rotated $(x) $(y) run summon marker ^ ^-0.1 ^1.5 {Tags:[scast.reposition]}
scoreboard players operation @n[type=marker, tag=scast.reposition] scast.caster_id = @s scast.caster_id