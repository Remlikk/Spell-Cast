scoreboard players set #scast scast.iterate 0
execute unless data storage scast:catalog spell_names[0] run return run tellraw @s {text: "No spells found!", color: "red"}

function scast:internal/loop_spell_names with storage scast:catalog