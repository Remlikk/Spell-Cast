scoreboard players set #scast scast.success 0
$execute store success score #scast scast.success if data storage scast:catalog spells[]."$(sequence)"
execute if score #scast scast.success matches 1 run tellraw @s [{text: "Error: ", color: "red"}, {text: "A spell with this sequence already exists!"}]
execute if score #scast scast.success matches 1 run return fail

scoreboard players set #scast scast.iterate 0
$execute store result score #scast scast.success run function scast:internal/iterate_spells {name:"$(name)"}
execute if score #scast scast.success matches 1 run tellraw @s [{text: "Error: ", color: "red"}, {text: "A spell with this name already exists!"}]
execute if score #scast scast.success matches 1 run return fail

$data modify storage scast:catalog spells append value {"$(sequence)": {name:"$(name)", function:"$(function)", cooldown:$(cooldown)s}}
$data modify storage scast:catalog spell_keys append value "$(sequence)"
$data modify storage scast:catalog spell_names append value "$(name)"
$tellraw @s ["Spell ",{text:"$(name)",color:"light_purple"}, " has been registered!"]