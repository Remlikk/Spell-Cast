scoreboard players set #scast scast.iterate 0
$execute store result score #scast scast.success run function scast:internal/iterate_spells {name:"$(old)"}

execute if score #scast scast.success matches 1 run function scast:internal/get_sequence_at_index with storage scast:data
# execute if score #scast scast.success matches 1 run data modify storage scast:data spell_sequence set from storage scast:catalog iter_spell
$execute if score #scast scast.success matches 1 run data merge storage scast:data {new_spell_name:"$(new)"}
execute if score #scast scast.success matches 1 run function scast:internal/overwrite_spell_at_index with storage scast:data

$execute if score #scast scast.success matches 1 run tellraw @s ["Successfully renamed spell ", {text: "$(old)", color: "light_purple"}, {text: " to "}, {text: "$(new)", color: "light_purple"}]
execute if score #scast scast.success matches 0 run tellraw @s [{text: "Error: ", color: "red"}, {text: "Spell not found!"}]