scoreboard players set #scast scast.iterate 0
$execute store result score #scast scast.success run function scast:internal/iterate_spells {name:"$(name)"}
execute if score #scast scast.success matches 1 run function scast:internal/remove_spell_at_index with storage scast:data
$execute if score #scast scast.success matches 1 run tellraw @s ["Successfully removed spell ", {text: "$(name)", color: "light_purple"}]
execute if score #scast scast.success matches 0 run tellraw @s [{text: "Error: ", color: "red"}, {text: "Spell not found!"}]